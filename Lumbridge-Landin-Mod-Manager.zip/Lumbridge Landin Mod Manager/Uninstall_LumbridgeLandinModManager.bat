@echo off
echo Uninstalling Lumbridge Landin Mod Manager...
schtasks /Delete /TN "LumbridgeLandin Mod Update Check" /F >nul 2>&1
rmdir /S /Q "C:\Users\jules\AppData\Local\Lumbridge Landin Mod Manager"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$d=(New-Object -ComObject WScript.Shell).SpecialFolders('Desktop'); Remove-Item -LiteralPath (Join-Path $d 'Lumbridge Landin Mod Manager.lnk') -Force -ErrorAction SilentlyContinue"
echo Uninstall complete.
pause
