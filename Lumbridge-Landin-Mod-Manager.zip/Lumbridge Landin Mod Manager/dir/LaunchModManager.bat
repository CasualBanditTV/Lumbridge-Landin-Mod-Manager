@echo off
echo Starting Lumbridge Landin Mod Manager...
powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0LumbridgeLandinModManager.ps1"
echo.
echo If the window did not open, PowerShell is blocked on this PC.
pause
