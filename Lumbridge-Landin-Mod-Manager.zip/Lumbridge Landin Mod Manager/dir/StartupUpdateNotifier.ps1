﻿# Lumbridge Landin Mod Manager startup update notifier
# Runs silently at user logon; only displays a notification when an update is needed.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$installDir = Join-Path $env:LOCALAPPDATA 'Lumbridge Landin Mod Manager\dir'
$appScript = Join-Path $installDir 'LumbridgeLandinModManager.ps1'
$iconPath = Join-Path $installDir 'images\dragon.ico'
$versionUrl = 'https://raw.githubusercontent.com/CasualBanditTV/dragonwilds-server-mods/main/version.txt'

function Get-GameModsFolder {
    $libraryRoots = @()
    $steamRoots = @(
        (Join-Path $env:ProgramFiles 'Steam'),
        (Join-Path ${env:ProgramFiles(x86)} 'Steam'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Steam')
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }

    foreach ($steamRoot in $steamRoots) {
        $libraryRoots += (Join-Path $steamRoot 'steamapps')
        $vdf = Join-Path $steamRoot 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            $raw = Get-Content -LiteralPath $vdf -Raw -ErrorAction SilentlyContinue
            foreach ($match in [regex]::Matches($raw, '"path"\s+"([^"]+)"')) {
                $libPath = $match.Groups[1].Value.Replace('\\','\')
                $libraryRoots += (Join-Path $libPath 'steamapps')
            }
        }
    }

    foreach ($steamApps in @($libraryRoots | Select-Object -Unique)) {
        $game = Join-Path $steamApps 'common\RSDragonwilds'
        if (Test-Path -LiteralPath $game -PathType Container) {
            return (Join-Path $game 'Content\Paks\~mods')
        }
    }
    return $null
}

try {
    if (-not (Test-Path -LiteralPath $appScript -PathType Leaf)) { exit 0 }
    $modsDir = Get-GameModsFolder
    if (-not $modsDir) { exit 0 }

    $onlineResponse = Invoke-WebRequest -Uri $versionUrl -UseBasicParsing -TimeoutSec 15 -ErrorAction Stop
    $onlineVersion = ([string]$onlineResponse.Content).Trim()
    if ([string]::IsNullOrWhiteSpace($onlineVersion) -or $onlineVersion.Length -gt 100 -or $onlineVersion -match '[\r\n]') { exit 0 }

    $localVersion = $null
    $versionFile = Join-Path $modsDir 'localversion.txt'
    if ((Test-Path -LiteralPath $modsDir -PathType Container) -and (Test-Path -LiteralPath $versionFile -PathType Leaf)) {
        $pakFiles = @(Get-ChildItem -LiteralPath $modsDir -File -Recurse -Filter '*.pak' -ErrorAction SilentlyContinue)
        if ($pakFiles.Count -gt 0) {
            $candidate = (Get-Content -LiteralPath $versionFile -Raw -ErrorAction SilentlyContinue).Trim()
            if (-not [string]::IsNullOrWhiteSpace($candidate) -and $candidate.Length -le 100 -and $candidate -notmatch '[\r\n]') {
                $localVersion = $candidate
            }
        }
    }

    $needsUpdate = [string]::IsNullOrWhiteSpace($localVersion) -or
        -not [string]::Equals($localVersion, $onlineVersion, [System.StringComparison]::OrdinalIgnoreCase)
    if (-not $needsUpdate) { exit 0 }

    $notify = New-Object System.Windows.Forms.NotifyIcon
    $notify.Text = 'Lumbridge Landin Mod Manager'
    if (Test-Path -LiteralPath $iconPath -PathType Leaf) {
        $notify.Icon = New-Object System.Drawing.Icon($iconPath)
    } else {
        $notify.Icon = [System.Drawing.SystemIcons]::Information
    }
    $notify.Visible = $true

    $menu = New-Object System.Windows.Forms.ContextMenuStrip
    $openItem = $menu.Items.Add('Open Lumbridge Landin Mod Manager')
    $openItem.Add_Click({
        Start-Process -FilePath 'powershell.exe' -ArgumentList @(
            '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $appScript + '"')
        )
        $notify.Visible = $false
        $notify.Dispose()
        $menu.Dispose()
        [System.Windows.Forms.Application]::Exit()
    })
    $exitItem = $menu.Items.Add('Dismiss')
    $exitItem.Add_Click({
        $notify.Visible = $false
        $notify.Dispose()
        $menu.Dispose()
        [System.Windows.Forms.Application]::Exit()
    })
    $notify.ContextMenuStrip = $menu
    $notify.add_BalloonTipClicked({
        Start-Process -FilePath 'powershell.exe' -ArgumentList @(
            '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $appScript + '"')
        )
        $notify.Visible = $false
        $notify.Dispose()
        $menu.Dispose()
        [System.Windows.Forms.Application]::Exit()
    })

    $notify.BalloonTipTitle = 'Lumbridge Landin Mod Manager'
    if ([string]::IsNullOrWhiteSpace($localVersion)) {
        $notify.BalloonTipText = "Mods could not be verified. Open the mod manager to update."
    } else {
        $notify.BalloonTipText = "A mod update is available ($localVersion to $onlineVersion). Click to open the mod manager."
    }
    $notify.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Info
    $notify.ShowBalloonTip(10000)

    # Keep the hidden process alive long enough for the user to click the notification.
    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 1000
    $elapsed = 0
    $timer.Add_Tick({
        $script:elapsed += 1
        if ($script:elapsed -ge 60) {
            $timer.Stop()
            $notify.Visible = $false
            $notify.Dispose()
            $menu.Dispose()
            [System.Windows.Forms.Application]::Exit()
        }
    })
    $script:elapsed = 0
    $timer.Start()
    [System.Windows.Forms.Application]::Run()
} catch {
    # Startup update checks must never interrupt Windows startup.
    exit 0
}
