Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}


function Get-DragonwildsGamePath {
    # Discover Steam installs from registry and common locations, then inspect
    # every configured Steam library for the game's actual install manifest.
    $steamRoots = New-Object System.Collections.Generic.List[string]

    foreach ($key in @(
        'HKCU:\Software\Valve\Steam',
        'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam',
        'HKLM:\SOFTWARE\Valve\Steam'
    )) {
        try {
            $props = Get-ItemProperty -LiteralPath $key -ErrorAction Stop
            foreach ($value in @($props.InstallPath, $props.SteamPath)) {
                if (-not [string]::IsNullOrWhiteSpace([string]$value)) {
                    $steamRoots.Add(([string]$value -replace '/', '\').TrimEnd('\'))
                }
            }
        } catch {}
    }

    foreach ($root in @(
        "${env:ProgramFiles(x86)}\Steam",
        "$env:ProgramFiles\Steam",
        "$env:SystemDrive\Steam",
        "$env:LOCALAPPDATA\Programs\Steam",
        'C:\Steam',
        'D:\Steam',
        'D:\SteamLibrary'
    )) {
        if (-not [string]::IsNullOrWhiteSpace($root)) {
            $steamRoots.Add($root.TrimEnd('\'))
        }
    }

    $libraryRoots = New-Object System.Collections.Generic.List[string]
    foreach ($steamRoot in @($steamRoots | Select-Object -Unique)) {
        if (Test-Path -LiteralPath $steamRoot -PathType Container) {
            $libraryRoots.Add($steamRoot)

            $steamApps = Join-Path $steamRoot 'steamapps'
            $libraryVdf = Join-Path $steamApps 'libraryfolders.vdf'
            if (Test-Path -LiteralPath $libraryVdf -PathType Leaf) {
                try {
                    $content = Get-Content -LiteralPath $libraryVdf -Raw -ErrorAction Stop
                    foreach ($match in [regex]::Matches($content, '"path"\s+"([^"]+)"')) {
                        $library = $match.Groups[1].Value -replace '\\\\', '\'
                        if (-not [string]::IsNullOrWhiteSpace($library)) {
                            $libraryRoots.Add($library.TrimEnd('\'))
                        }
                    }
                } catch {}
            }

            # Older libraryfolders.vdf format: numbered library entries.
            if (Test-Path -LiteralPath $libraryVdf -PathType Leaf) {
                try {
                    $content = Get-Content -LiteralPath $libraryVdf -Raw -ErrorAction Stop
                    foreach ($match in [regex]::Matches($content, '"\d+"\s+"([^"]+)"')) {
                        $library = $match.Groups[1].Value -replace '\\\\', '\'
                        if (-not [string]::IsNullOrWhiteSpace($library)) {
                            $libraryRoots.Add($library.TrimEnd('\'))
                        }
                    }
                } catch {}
            }
        }
    }

    foreach ($library in @($libraryRoots | Select-Object -Unique)) {
        $manifest = Join-Path $library 'steamapps\appmanifest_1374490.acf'
        $game = Join-Path $library 'steamapps\common\RSDragonwilds'

        # The manifest is the strongest signal; still verify the game folder.
        if ((Test-Path -LiteralPath $manifest -PathType Leaf) -and
            (Test-Path -LiteralPath $game -PathType Container)) {
            return $game
        }
    }

    # Fallback for installs whose manifest is absent or whose app ID changes:
    # verify the game directory exists in a configured library.
    foreach ($library in @($libraryRoots | Select-Object -Unique)) {
        $game = Join-Path $library 'steamapps\common\RSDragonwilds'
        if (Test-Path -LiteralPath $game -PathType Container) {
            return $game
        }
    }

    return $null
}

function Get-LocalModVersion {
    param([Parameter(Mandatory=$true)][string]$ModsDirectory)

    # Only trust localversion.txt, which this manager writes after a successful
    # install. Do not trust version.txt: it may be part of an archive or unrelated.
    if (-not (Test-Path -LiteralPath $ModsDirectory -PathType Container)) {
        return [pscustomobject]@{ Version = $null; File = $null }
    }

    $versionFile = Join-Path $ModsDirectory 'localversion.txt'
    if (-not (Test-Path -LiteralPath $versionFile -PathType Leaf)) {
        return [pscustomobject]@{ Version = $null; File = $null }
    }

    try {
        $value = (Get-Content -LiteralPath $versionFile -Raw -ErrorAction Stop).Trim()
        if ([string]::IsNullOrWhiteSpace($value) -or $value.Length -gt 100 -or $value -match '[\r\n]') {
            return [pscustomobject]@{ Version = $null; File = $null }
        }

        # A marker or unrelated files are not proof that the mod payload exists.
        # Dragonwilds pak mods use .pak files (often with matching .utoc/.ucas files).
        $pakFiles = @(Get-ChildItem -LiteralPath $ModsDirectory -File -Recurse -Filter '*.pak' -ErrorAction SilentlyContinue)
        if ($pakFiles.Count -eq 0) {
            return [pscustomobject]@{ Version = $null; File = $null }
        }

        return [pscustomobject]@{
            Version = $value
            File = $versionFile
        }
    } catch {
        return [pscustomobject]@{ Version = $null; File = $null }
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "Lumbridge Landin - Dragonwilds Mod Manager"
$form.Size = New-Object System.Drawing.Size(650, 500)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false

# BACKGROUND IMAGE
$bgPath = Join-Path $PSScriptRoot/images "background.png"
$bg = New-Object System.Windows.Forms.PictureBox
$bg.Dock = "Fill"
$bg.SizeMode = "StretchImage"

if (Test-Path $bgPath) {
    try { $bg.Image = [System.Drawing.Image]::FromFile($bgPath) }
    catch { $bg.Image = $null }
}

$form.Controls.Add($bg)

###############################################
# HEADER WITH SHADOW
###############################################

$headerShadow = New-Object System.Windows.Forms.Label
$headerShadow.Text = "Lumbridge Landin Mod Manager"
$headerShadow.ForeColor = [System.Drawing.Color]::FromArgb(120, 0, 0, 0)
$headerShadow.BackColor = [System.Drawing.Color]::Transparent
$headerShadow.Font = New-Object System.Drawing.Font("Segoe UI", 24, [System.Drawing.FontStyle]::Bold)
$headerShadow.AutoSize = $true
$headerShadow.Location = New-Object System.Drawing.Point(63, 23)
$form.Controls.Add($headerShadow)

$header = New-Object System.Windows.Forms.Label
$header.Text = "Lumbridge Landin Mod Manager"
$header.ForeColor = [System.Drawing.Color]::FromArgb(255, 255, 215, 0)
$header.BackColor = [System.Drawing.Color]::Transparent
$header.Font = New-Object System.Drawing.Font("Segoe UI", 24, [System.Drawing.FontStyle]::Bold)
$header.AutoSize = $true
$header.Location = New-Object System.Drawing.Point(60, 20)
$form.Controls.Add($header)

###############################################
# STATUS TEXT WITH SHADOW (NO OVERLAP EVER)
###############################################

$statusShadow = New-Object System.Windows.Forms.Label
$statusShadow.Text = "Status: Idle"
$statusShadow.ForeColor = [System.Drawing.Color]::FromArgb(120, 0, 0, 0)
$statusShadow.BackColor = [System.Drawing.Color]::Transparent
$statusShadow.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$statusShadow.AutoSize = $false
$statusShadow.Size = New-Object System.Drawing.Size(590, 62)
$statusShadow.TextAlign = [System.Drawing.ContentAlignment]::TopLeft
$statusShadow.Location = New-Object System.Drawing.Point(33, 150)
$form.Controls.Add($statusShadow)

$status = New-Object System.Windows.Forms.Label
$status.Text = "Status: Idle"
$status.ForeColor = [System.Drawing.Color]::FromArgb(255, 255, 215, 0)
$status.BackColor = [System.Drawing.Color]::Transparent
$status.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$status.AutoSize = $false
$status.Size = New-Object System.Drawing.Size(590, 62)
$status.TextAlign = [System.Drawing.ContentAlignment]::TopLeft
$status.Location = New-Object System.Drawing.Point(30, 147)
$form.Controls.Add($status)

###############################################
# PROGRESS BAR (LOWER SO NOTHING TOUCHES)
###############################################

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Location = New-Object System.Drawing.Point(30, 220)
$progress.Size = New-Object System.Drawing.Size(580, 25)
$form.Controls.Add($progress)

###############################################
# BUTTONS
###############################################

# UPDATE BUTTON
$updateButton = New-Object System.Windows.Forms.Button
$updateButton.Text = "Update Mods"
$updateButton.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$updateButton.BackColor = "#333333"
$updateButton.ForeColor = "#FFD700"
$updateButton.Size = New-Object System.Drawing.Size(200, 50)
$updateButton.Location = New-Object System.Drawing.Point(220, 270)
$form.Controls.Add($updateButton)

# CHECK VERSION BUTTON
$checkButton = New-Object System.Windows.Forms.Button
$checkButton.Text = "Check Version"
$checkButton.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$checkButton.BackColor = "#333333"
$checkButton.ForeColor = "White"
$checkButton.Size = New-Object System.Drawing.Size(200, 40)
$checkButton.Location = New-Object System.Drawing.Point(220, 330)
$form.Controls.Add($checkButton)

# EXIT BUTTON
$exitButton = New-Object System.Windows.Forms.Button
$exitButton.Text = "Exit"
$exitButton.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$exitButton.BackColor = "#333333"
$exitButton.ForeColor = "White"
$exitButton.Size = New-Object System.Drawing.Size(100, 40)
$exitButton.Location = New-Object System.Drawing.Point(270, 380)
$form.Controls.Add($exitButton)

$exitButton.Add_Click({ $form.Close() })

###############################################
# FORCE BACKGROUND BEHIND EVERYTHING
###############################################

$form.Controls.SetChildIndex($bg, $form.Controls.Count - 1)

###############################################
# VERSION CHECK LOGIC
###############################################

$checkButton.Add_Click({
    $status.Text = "Status: Checking local and online versions..."
    $statusShadow.Text = $status.Text
    $progress.Value = 15
    $form.Refresh()

    $gamePath = Get-DragonwildsGamePath
    if ([string]::IsNullOrWhiteSpace([string]$gamePath)) {
        $status.Text = "Status: Game not found - check Steam installation"
        $statusShadow.Text = $status.Text
        $progress.Value = 0
        [System.Windows.Forms.MessageBox]::Show(
            "RuneScape: Dragonwilds could not be found in the detected Steam libraries. Open Steam > game > Manage > Browse local files to confirm its installation folder.",
            "Game not found",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }

    $targetDir = Join-Path $gamePath 'Content\Paks\~mods'
    $localInfo = Get-LocalModVersion -ModsDirectory $targetDir
    $localVersion = [string]$localInfo.Version
    $progress.Value = 40
    $status.Text = "Status: Fetching online version..."
    $statusShadow.Text = $status.Text
    $form.Refresh()

    try {
        $onlineVersionResponse = Invoke-WebRequest -Uri "https://raw.githubusercontent.com/CasualBanditTV/dragonwilds-server-mods/main/version.txt" -UseBasicParsing -TimeoutSec 20 -ErrorAction Stop
        $onlineVersion = ([string]$onlineVersionResponse.Content).Trim()
        if ([string]::IsNullOrWhiteSpace($onlineVersion) -or $onlineVersion.Length -gt 100 -or $onlineVersion -match '[\r\n]') {
            throw "The online version file is empty or invalid."
        }
    } catch {
        $status.Text = "Status: ERROR - Could not fetch online version"
        $statusShadow.Text = $status.Text
        $progress.Value = 0
        return
    }

    $progress.Value = 100
    if ([string]::IsNullOrWhiteSpace($localVersion)) {
        $status.Text = "Mods NOT VERIFIED | Update available: YES`r`nOnline version: $onlineVersion | Local version: unknown"
    } elseif ([string]::Equals($localVersion.Trim(), $onlineVersion.Trim(), [System.StringComparison]::OrdinalIgnoreCase)) {
        $status.Text = "UP TO DATE | Update available: NO`r`nLocal: $localVersion | Online: $onlineVersion"
    } else {
        $status.Text = "UPDATE AVAILABLE | Update available: YES`r`nLocal: $localVersion | Online: $onlineVersion"
    }
    $statusShadow.Text = $status.Text
})

###############################################
# UPDATE LOGIC
###############################################

$updateButton.Add_Click({

    $progress.Value = 10
    $status.Text = "Status: Detecting game path..."
    $statusShadow.Text = $status.Text

    $gamePath = Get-DragonwildsGamePath
    if (-not $gamePath) {
        $status.Text = "Status: ERROR - Game not found in detected Steam libraries"
        $statusShadow.Text = $status.Text
        $progress.Value = 0
        [System.Windows.Forms.MessageBox]::Show(
            "Could not find RuneScape: Dragonwilds in your Steam libraries. Open Steam, right-click the game, choose Manage > Browse local files, and verify the folder is named RSDragonwilds.",
            "Game not found",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }

    $progress.Value = 20
    $status.Text = "Status: Checking version..."
    $statusShadow.Text = $status.Text

    $targetDir = Join-Path $gamePath 'Content\Paks\~mods'
    if (-not (Test-Path -LiteralPath $targetDir -PathType Container)) {
        try {
            New-Item -ItemType Directory -Path $targetDir -Force -ErrorAction Stop | Out-Null
        } catch {
            $status.Text = "Status: ERROR - Could not create ~mods folder"
            $statusShadow.Text = $status.Text
            $progress.Value = 0
            return
        }
    }

    $localVerFile = Join-Path $targetDir 'localversion.txt'
    $localInfo = Get-LocalModVersion -ModsDirectory $targetDir
    $localVersion = $localInfo.Version

    try {
        $onlineVersionResponse = Invoke-WebRequest -Uri "https://raw.githubusercontent.com/CasualBanditTV/dragonwilds-server-mods/main/version.txt" -UseBasicParsing -TimeoutSec 20 -ErrorAction Stop
        $onlineVersion = ([string]$onlineVersionResponse.Content).Trim()
        if ([string]::IsNullOrWhiteSpace($onlineVersion) -or $onlineVersion.Length -gt 100 -or $onlineVersion -match '[\r\n]') {
            throw "The online version file is empty or invalid."
        }
    } catch {
        $status.Text = "Status: ERROR - Could not fetch server version"
        $statusShadow.Text = $status.Text
        $progress.Value = 0
        return
    }

    if (-not [string]::IsNullOrWhiteSpace($localVersion) -and
        [string]::Equals($localVersion.Trim(), $onlineVersion.Trim(), [System.StringComparison]::OrdinalIgnoreCase)) {
        $status.Text = "Status: Mods already up to date ($localVersion)"
        $statusShadow.Text = $status.Text
        $progress.Value = 100
        return
    }

    $progress.Value = 40
    if ([string]::IsNullOrWhiteSpace($localVersion)) {
        $status.Text = "Status: Local version unknown - downloading current mods..."
    } else {
        $status.Text = "Status: Updating $localVersion to $onlineVersion..."
    }
    $statusShadow.Text = $status.Text

    $tempRoot = Join-Path $env:TEMP ("LumbridgeLandinMods_" + [guid]::NewGuid().ToString('N'))
    $tempZip = Join-Path $tempRoot 'mods_server.zip'
    $extractDir = Join-Path $tempRoot 'extracted'
    $localVerFile = Join-Path $targetDir 'localversion.txt'

    try {
        New-Item -ItemType Directory -Path $extractDir -Force -ErrorAction Stop | Out-Null
    } catch {
        $status.Text = "Status: ERROR - Could not prepare temporary update folder"
        $statusShadow.Text = $status.Text
        $progress.Value = 0
        return
    }

    $progress.Value = 40
    $status.Text = "Status: Downloading mods..."
    $statusShadow.Text = $status.Text

    try {
        Invoke-WebRequest -Uri "https://raw.githubusercontent.com/CasualBanditTV/dragonwilds-server-mods/main/mods.zip" -OutFile $tempZip -TimeoutSec 120 -ErrorAction Stop
        if (-not (Test-Path -LiteralPath $tempZip -PathType Leaf) -or (Get-Item -LiteralPath $tempZip).Length -le 0) {
            throw "Downloaded ZIP is missing or empty."
        }
    } catch {
        $status.Text = "Status: ERROR - Failed to download mods.zip"
        $statusShadow.Text = $status.Text
        $progress.Value = 0
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
        return
    }

    $progress.Value = 60
    $status.Text = "Status: Extracting mods..."
    $statusShadow.Text = $status.Text

    try {
        Expand-Archive -LiteralPath $tempZip -DestinationPath $extractDir -Force -ErrorAction Stop

        # Some releases package files under a top-level "mods" directory.
        $sourceDir = $extractDir
        $nestedMods = Join-Path $extractDir 'mods'
        if (Test-Path -LiteralPath $nestedMods -PathType Container) {
            $topLevelItems = @(Get-ChildItem -LiteralPath $extractDir -Force)
            if ($topLevelItems.Count -eq 1 -and $topLevelItems[0].PSIsContainer -and $topLevelItems[0].Name -eq 'mods') {
                $sourceDir = $nestedMods
            }
        }

        $payload = @(Get-ChildItem -LiteralPath $sourceDir -Force)
        if ($payload.Count -eq 0) {
            throw "The downloaded archive contains no files."
        }
    } catch {
        $status.Text = "Status: ERROR - ZIP extraction failed"
        $statusShadow.Text = $status.Text
        $progress.Value = 0
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
        return
    }

    $progress.Value = 75
    $status.Text = "Status: Fixing folder structure..."
    $statusShadow.Text = $status.Text

    try {
        foreach ($item in $payload) {
            Copy-Item -LiteralPath $item.FullName -Destination $targetDir -Recurse -Force -ErrorAction Stop
        }

        # Record the version only after the payload has copied successfully.
        Set-Content -LiteralPath $localVerFile -Value $onlineVersion -Encoding ASCII -ErrorAction Stop
    } catch {
        $status.Text = "Status: ERROR - Could not install mod files"
        $statusShadow.Text = $status.Text
        $progress.Value = 0
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
        return
    } finally {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }

    $progress.Value = 100
    $status.Text = "Status: Update complete! Installed version: $onlineVersion"
    $statusShadow.Text = $status.Text
})

# FIRST-STARTUP GAME DETECTION
# Popup is intentionally limited to whether the game itself was found.
$form.Add_Shown({
    $status.Text = "Status: Looking for game files..."
    $statusShadow.Text = $status.Text
    $progress.Value = 20
    $form.Refresh()
    [System.Windows.Forms.Application]::DoEvents()

    $startupGamePath = Get-DragonwildsGamePath
    if ([string]::IsNullOrWhiteSpace([string]$startupGamePath)) {
        $status.Text = "Status: Game not found - check Steam installation"
        $statusShadow.Text = $status.Text
        $progress.Value = 0
        [System.Windows.Forms.MessageBox]::Show(
            "RuneScape: Dragonwilds was NOT FOUND in the detected Steam libraries. If it is installed, open Steam > RuneScape: Dragonwilds > Manage > Browse local files and confirm the folder location.",
            "Game files not found",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }

    $status.Text = "Status: Game found - click Check Version"
    $statusShadow.Text = $status.Text
    $progress.Value = 100
    [System.Windows.Forms.MessageBox]::Show(
        "RuneScape: Dragonwilds was found.`r`n`r`nGame folder:`r`n$startupGamePath`r`n`r`nUse Check Version to check the local mod files and online version.",
        "Game files found",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
})

$form.Add_FormClosed({
    if ($bg.Image) {
        $img = $bg.Image
        $bg.Image = $null
        $img.Dispose()
    }
})

[void]$form.ShowDialog()
