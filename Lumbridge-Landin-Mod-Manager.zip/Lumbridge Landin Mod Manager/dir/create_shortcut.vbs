Set oWS = CreateObject("WScript.Shell")
desktopPath = oWS.SpecialFolders("Desktop")
shortcutPath = desktopPath & "\Lumbridge Landin Mod Manager.lnk"
installPath = "C:\Users\jules\AppData\Local\Lumbridge Landin Mod Manager\dir\"
Set oLink = oWS.CreateShortcut(shortcutPath)
oLink.TargetPath = installPath & "LaunchModManager.bat"
oLink.IconLocation = installPath & "images\dragon.ico"
oLink.WorkingDirectory = installPath
oLink.Save
