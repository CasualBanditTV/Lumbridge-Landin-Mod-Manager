@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Lumbridge Landin Mod Manager Installer

set "APPNAME=Lumbridge Landin Mod Manager"
set "REPO=CasualBanditTV/Lumbridge-Landin-Mod-Manager"
set "RELEASEZIP=Lumbridge.Landin.Mod.Manager.zip"
set "MAINFOLDER=Lumbridge Landin Mod Manager"
set "INSTALLROOT=%LOCALAPPDATA%"
set "INSTALLDIR=%LOCALAPPDATA%\Lumbridge Landin Mod Manager"
set "INSTALLEDVERSION=InstalledVersion.txt"
set "LAUNCHER=LaunchModManager.bat"
set "ICON=dir\images\dragon.ico"
set "SHORTCUTNAME=Lumbridge Landin Mod Manager.lnk"

set "WORKDIR=%TEMP%\LumbridgeLandinModManager_Installer"
set "ZIPFILE=%WORKDIR%\%RELEASEZIP%"
set "EXTRACTDIR=%WORKDIR%\Extracted"
set "RELEASEINFO=%WORKDIR%\release.txt"
set "RELEASETAGFILE=%WORKDIR%\release_tag.txt"
set "ASSETURLFILE=%WORKDIR%\asset_url.txt"
set "PACKAGEPATHFILE=%WORKDIR%\package_path.txt"

echo.
echo ============================================================
echo        Lumbridge Landin Mod Manager Installer
echo ============================================================
echo.

if exist "%WORKDIR%" rmdir /S /Q "%WORKDIR%" >nul 2>&1
mkdir "%WORKDIR%" >nul 2>&1

echo Checking the latest GitHub release...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "$u='https://api.github.com/repos/%REPO%/releases/latest';" ^
  "$h=@{'Accept'='application/vnd.github+json';'X-GitHub-Api-Version'='2026-03-10'};" ^
  "$r=Invoke-RestMethod -Uri $u -Headers $h -UseBasicParsing;" ^
  "$a=@($r.assets | Where-Object { $_.name -eq '%RELEASEZIP%' });" ^
  "if($a.Count -ne 1){throw 'Could not find exactly one release asset named %RELEASEZIP%.'};" ^
  "[IO.File]::WriteAllText('%RELEASETAGFILE%', [string]$r.tag_name, [Text.Encoding]::ASCII);" ^
  "[IO.File]::WriteAllText('%ASSETURLFILE%', [string]$a[0].browser_download_url, [Text.Encoding]::ASCII);" ^
  "[IO.File]::WriteAllText('%RELEASEINFO%', [string]$r.tag_name, [Text.Encoding]::ASCII)"
if errorlevel 1 goto :github_error

set /p RELEASETAG=<"%RELEASETAGFILE%"
set /p ASSETURL=<"%ASSETURLFILE%"

if not defined RELEASETAG (
    echo ERROR: GitHub did not return a release tag.
    goto :fail
)

if not defined ASSETURL (
    echo ERROR: GitHub did not return a download URL for %RELEASEZIP%.
    goto :fail
)

echo Latest release: %RELEASETAG%
echo.

rem ------------------------------------------------------------
rem Existing installation check
rem ------------------------------------------------------------
if not exist "%INSTALLDIR%\" (
    echo No existing installation was found.
    echo A fresh installation will be performed.
    echo.
    goto :download
)

echo Existing installation found:
echo %INSTALLDIR%
echo.

if not exist "%INSTALLDIR%\%INSTALLEDVERSION%" (
    echo WARNING: %INSTALLEDVERSION% was not found.
    echo The installation will be repaired using the latest release.
    echo.
    goto :download
)

set "LOCALVERSION="
set /p LOCALVERSION=<"%INSTALLDIR%\%INSTALLEDVERSION%"

if not defined LOCALVERSION (
    echo WARNING: %INSTALLEDVERSION% is empty.
    echo The installation will be repaired using the latest release.
    echo.
    goto :download
)

set "LOCALVERSION=%LOCALVERSION: =%"

echo Installed version: %LOCALVERSION%
echo Latest version:    %RELEASETAG%
echo.

if /I "%LOCALVERSION%"=="%RELEASETAG%" (
    echo The installed version is already up to date.
    echo No download or replacement is required.
    echo.
    goto :shortcut
)

echo A newer version is available.
echo The existing installation will be replaced completely.
echo.

rem ------------------------------------------------------------
rem Download
rem ------------------------------------------------------------
:download
echo Downloading %RELEASEZIP%...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "$u=Get-Content -Raw -LiteralPath '%ASSETURLFILE%';" ^
  "$u=$u.Trim();" ^
  "Invoke-WebRequest -Uri $u -OutFile '%ZIPFILE%' -UseBasicParsing"
if errorlevel 1 goto :download_error

if not exist "%ZIPFILE%" (
    echo ERROR: The ZIP file was not downloaded.
    goto :fail
)

echo Download complete.
echo.

rem ------------------------------------------------------------
rem Extract
rem ------------------------------------------------------------
if exist "%EXTRACTDIR%" rmdir /S /Q "%EXTRACTDIR%" >nul 2>&1
mkdir "%EXTRACTDIR%" >nul 2>&1

echo Extracting package...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "Expand-Archive -LiteralPath '%ZIPFILE%' -DestinationPath '%EXTRACTDIR%' -Force"
if errorlevel 1 goto :extract_error

echo Extraction complete.
echo.

rem ------------------------------------------------------------
rem Find the exact main folder anywhere in the extracted package.
rem ------------------------------------------------------------
set "PACKAGEPATH="

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "$root=(Resolve-Path -LiteralPath '%EXTRACTDIR%').Path;" ^
  "$hits=@(Get-ChildItem -LiteralPath $root -Directory -Recurse -Force | Where-Object { $_.Name -eq '%MAINFOLDER%' });" ^
  "if($hits.Count -ne 1){throw ('Expected exactly one folder named %MAINFOLDER%, found ' + $hits.Count + '.')};" ^
  "[IO.File]::WriteAllText('%PACKAGEPATHFILE%', $hits[0].FullName, [Text.Encoding]::ASCII)"
if errorlevel 1 goto :package_error

set /p PACKAGEPATH=<"%PACKAGEPATHFILE%"

if not defined PACKAGEPATH (
    echo ERROR: Could not locate the package main folder.
    goto :fail
)

echo Package folder found:
echo %PACKAGEPATH%
echo.

rem ------------------------------------------------------------
rem Validate the new package before touching the current install.
rem ------------------------------------------------------------
if not exist "%PACKAGEPATH%\%INSTALLEDVERSION%" (
    echo ERROR: The new package does not contain:
    echo   %INSTALLEDVERSION%
    echo.
    echo The existing installation was NOT changed.
    goto :fail
)

if not exist "%PACKAGEPATH%\dir\" (
    echo ERROR: The new package does not contain:
    echo   dir\
    echo.
    echo The existing installation was NOT changed.
    goto :fail
)

set "PACKAGEVERSION="
set /p PACKAGEVERSION=<"%PACKAGEPATH%\%INSTALLEDVERSION%"

if not defined PACKAGEVERSION (
    echo ERROR: The new package has an empty %INSTALLEDVERSION%.
    echo.
    echo The existing installation was NOT changed.
    goto :fail
)

set "PACKAGEVERSION=%PACKAGEVERSION: =%"

echo Package version:  %PACKAGEVERSION%
echo GitHub version:   %RELEASETAG%
echo.

if /I not "%PACKAGEVERSION%"=="%RELEASETAG%" (
    echo ERROR: The package version does not match the GitHub release tag.
    echo.
    echo Package: %PACKAGEVERSION%
    echo GitHub:  %RELEASETAG%
    echo.
    echo The existing installation was NOT changed.
    goto :fail
)

echo Package version verified successfully.
echo.

rem ------------------------------------------------------------
rem Replace the entire existing main folder.
rem ------------------------------------------------------------
if exist "%INSTALLDIR%\" (
    echo Removing the existing installation...
    rmdir /S /Q "%INSTALLDIR%"
    if exist "%INSTALLDIR%\" (
        echo ERROR: Could not remove the existing installation.
        echo.
        echo The existing installation was NOT replaced.
        goto :fail
    )
)

echo Installing the new main folder...
move "%PACKAGEPATH%" "%INSTALLROOT%\" >nul
if errorlevel 1 (
    echo ERROR: Could not move the new main folder into:
    echo %INSTALLROOT%
    goto :fail
)

if not exist "%INSTALLDIR%\" (
    echo ERROR: The new installation folder was not created.
    goto :fail
)

echo Installation completed.
echo.

rem ------------------------------------------------------------
rem Desktop shortcut
rem ------------------------------------------------------------
:shortcut
echo Checking the Desktop shortcut...

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "$ws=New-Object -ComObject WScript.Shell;" ^
  "$desktop=$ws.SpecialFolders('Desktop');" ^
  "$shortcut=Join-Path $desktop '%SHORTCUTNAME%';" ^
  "$target=Join-Path '%INSTALLDIR%' 'dir\%LAUNCHER%';" ^
  "$workdir=Join-Path '%INSTALLDIR%' 'dir';" ^
  "$icon=Join-Path '%INSTALLDIR%' '%ICON%';" ^
  "if(-not (Test-Path -LiteralPath $target)){throw 'Launcher not found: ' + $target};" ^
  "$sc=$ws.CreateShortcut($shortcut);" ^
  "if(-not (Test-Path -LiteralPath $icon -PathType Leaf)){throw 'Icon not found: ' + $icon};" ^
  "$sc.TargetPath=$target;" ^
  "$sc.WorkingDirectory=$workdir;" ^
  "$sc.IconLocation=($icon + ',0');" ^
  "$sc.Description='%APPNAME%';" ^
  "$sc.Save();" ^
  "$check=$ws.CreateShortcut($shortcut);" ^
  "if($check.IconLocation -notlike ($icon + '*')){throw 'Shortcut icon was not saved correctly.'}"
if errorlevel 1 (
    echo WARNING: Could not create or repair the Desktop shortcut.
    echo The application installation itself is complete.
    goto :cleanup
)

echo Desktop shortcut is ready.
echo.

:cleanup
if exist "%WORKDIR%" rmdir /S /Q "%WORKDIR%" >nul 2>&1

echo ============================================================
echo Installation/update finished.
echo ============================================================
echo.
pause
exit /b 0

:github_error
echo.
echo ERROR: Could not retrieve the latest GitHub release.
goto :fail

:download_error
echo.
echo ERROR: Failed to download %RELEASEZIP%.
echo.
echo The existing installation was NOT changed.
goto :fail

:extract_error
echo.
echo ERROR: Failed to extract the downloaded package.
echo.
echo The existing installation was NOT changed.
goto :fail

:package_error
echo.
echo ERROR: Could not locate the package main folder.
echo.
echo The existing installation was NOT changed.
goto :fail

:fail
if exist "%WORKDIR%" rmdir /S /Q "%WORKDIR%" >nul 2>&1
echo.
echo ============================================================
echo Installer stopped.
echo ============================================================
echo.
pause
exit /b 1
